package celestialhotel.model;

public enum RoomType {
    STANDARD,
    DELUXE,
    SUITE,
    FAMILY
}
