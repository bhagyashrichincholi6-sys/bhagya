package celestialhotel;

import celestialhotel.model.Customer;
import celestialhotel.model.Reservation;
import celestialhotel.model.Room;
import celestialhotel.model.RoomType;
import celestialhotel.service.HotelService;
import celestialhotel.service.WebServer;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class Main {
    // ANSI Color Codes
    private static final String RESET = "\u001B[0m";
    private static final String BOLD = "\u001B[1m";
    private static final String CYAN = "\u001B[36m";
    private static final String BLUE = "\u001B[34m";
    private static final String GREEN = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String RED = "\u001B[31m";
    private static final String MAGENTA = "\u001B[35m";

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final HotelService hotel = new HotelService();
    private static final Scanner scanner = new Scanner(System.in);
    private static final WebServer webServer = new WebServer(8080, hotel);

    public static void main(String[] args) {
        webServer.start();
        seedData();
        displayWelcome();

        while (true) {
            showMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> addRoom();
                case 2 -> listRooms();
                case 3 -> searchRoomAvailability();
                case 4 -> addCustomer();
                case 5 -> createReservation();
                case 6 -> viewCustomerReservations();
                case 7 -> listAllReservations();
                case 8 -> cancelReservation();
                case 9 -> generateBill();
                case 10 -> viewDashboard();
                case 11 -> {
                    displayGoodbye();
                    webServer.stop();
                    return;
                }
                default -> printError("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayWelcome() {
        clearScreen();
        System.out.println(BOLD + CYAN + "╔══════════════════════════════════════════════════╗" + RESET);
        System.out.println(BOLD + CYAN + "║                                                  ║" + RESET);
        System.out.println(BOLD + CYAN + "║      " + MAGENTA + "✨ CELESTIAL HAVEN HOTEL MANAGEMENT ✨" + CYAN + "       ║" + RESET);
        System.out.println(BOLD + CYAN + "║                                                  ║" + RESET);
        System.out.println(BOLD + CYAN + "╚══════════════════════════════════════════════════╝" + RESET);
        System.out.println(YELLOW + "Welcome to your premium hotel management system!" + RESET);
        printDivider();
    }

    private static void showMenu() {
        System.out.println("\n" + BOLD + BLUE + "═══════════════ MAIN MENU ═══════════════" + RESET);
        System.out.println(BLUE + "╔" + RESET + " " + BOLD + "ROOM MANAGEMENT" + RESET);
        System.out.println(BLUE + "║" + RESET + "  1. " + GREEN + "Add New Room" + RESET);
        System.out.println(BLUE + "║" + RESET + "  2. " + GREEN + "View All Rooms" + RESET);
        System.out.println(BLUE + "║" + RESET + "  3. " + GREEN + "Search Available Rooms" + RESET);
        System.out.println(BLUE + "║" + RESET);
        System.out.println(BLUE + "╔" + RESET + " " + BOLD + "CUSTOMER MANAGEMENT" + RESET);
        System.out.println(BLUE + "║" + RESET + "  4. " + YELLOW + "Register Customer" + RESET);
        System.out.println(BLUE + "║" + RESET + "  5. " + YELLOW + "Make Reservation" + RESET);
        System.out.println(BLUE + "║" + RESET + "  6. " + YELLOW + "View My Reservations" + RESET);
        System.out.println(BLUE + "║" + RESET);
        System.out.println(BLUE + "╔" + RESET + " " + BOLD + "RESERVATION MANAGEMENT" + RESET);
        System.out.println(BLUE + "║" + RESET + "  7. " + MAGENTA + "View All Reservations" + RESET);
        System.out.println(BLUE + "║" + RESET + "  8. " + MAGENTA + "Cancel Reservation" + RESET);
        System.out.println(BLUE + "║" + RESET + "  9. " + MAGENTA + "Generate Bill" + RESET);
        System.out.println(BLUE + "║" + RESET);
        System.out.println(BLUE + "╔" + RESET + " " + BOLD + "REPORTS & ANALYTICS" + RESET);
        System.out.println(BLUE + "║" + RESET + "  10. " + CYAN + "Dashboard & Statistics" + RESET);
        System.out.println(BLUE + "║" + RESET + "  11. " + RED + "Exit Application" + RESET);
        System.out.println(BOLD + BLUE + "════════════════════════════════════════" + RESET);
    }

    private static void seedData() {
        // Add sample rooms
        hotel.addRoom(new Room(101, RoomType.STANDARD, 120.0, true));
        hotel.addRoom(new Room(102, RoomType.STANDARD, 120.0, true));
        hotel.addRoom(new Room(103, RoomType.DELUXE, 185.0, true));
        hotel.addRoom(new Room(104, RoomType.DELUXE, 185.0, true));
        hotel.addRoom(new Room(201, RoomType.SUITE, 260.0, true));
        hotel.addRoom(new Room(202, RoomType.FAMILY, 220.0, true));

        // Add sample customers
        hotel.addCustomer(new Customer("C-1001", "Aarav Singh", "9876543210", "aarav@email.com"));
        hotel.addCustomer(new Customer("C-1002", "Nia Sharma", "9988776655", "nia@email.com"));
        hotel.addCustomer(new Customer("C-1003", "Rohan Patel", "9123456789", "rohan@email.com"));
    }

    private static void addRoom() {
        printHeader("ADD NEW ROOM");
        try {
            int roomNumber = readInt("Enter room number: ");
            if (roomNumber <= 0) {
                printError("Room number must be a positive integer!");
                return;
            }
            
            if (hotel.findRoomByNumber(roomNumber) != null) {
                printError("Room number already exists!");
                return;
            }

            System.out.println("\n" + BOLD + "Available room types:" + RESET);
            int i = 1;
            for (RoomType type : RoomType.values()) {
                System.out.println("  " + i + ". " + type);
                i++;
            }
            
            String typeInput = readString("Enter room type: ").toUpperCase();
            RoomType type = RoomType.valueOf(typeInput);
            double price = readDouble("Enter price per night: $");
            if (price <= 0) {
                printError("Price per night must be greater than zero!");
                return;
            }
            
            hotel.addRoom(new Room(roomNumber, type, price, true));
            printSuccess("✓ Room #" + roomNumber + " added successfully!");
        } catch (Exception e) {
            printError("Invalid input. Please try again.");
        }
    }

    private static void listRooms() {
        printHeader("ALL ROOMS");
        List<Room> rooms = hotel.getAllRooms();
        
        if (rooms.isEmpty()) {
            printWarning("No rooms available.");
            return;
        }

        System.out.println(BOLD + "┌─────────────┬─────────────┬──────────────┬───────────────┐" + RESET);
        System.out.println(BOLD + "│ Room # │ Type     │ Price/Night  │ Status        │" + RESET);
        System.out.println(BOLD + "├─────────────┼─────────────┼──────────────┼───────────────┤" + RESET);
        
        for (Room room : rooms) {
            String status = room.isAvailable() ? GREEN + "AVAILABLE" + RESET : RED + "OCCUPIED" + RESET;
            System.out.printf(BOLD + "│ %-8d│ %-10s│ $%-11.2f│ %s%-13s│%s\n", 
                room.getRoomNumber(), room.getRoomType(), room.getPricePerNight(), 
                "", status, RESET);
        }
        System.out.println(BOLD + "└─────────────┴─────────────┴──────────────┴───────────────┘" + RESET);
    }

    private static void searchRoomAvailability() {
        printHeader("SEARCH AVAILABLE ROOMS");
        try {
            System.out.println("\n" + BOLD + "Available room types:" + RESET);
            int i = 1;
            for (RoomType type : RoomType.values()) {
                System.out.println("  " + i + ". " + type);
                i++;
            }
            
            String typeInput = readString("Enter room type: ").toUpperCase();
            RoomType type = RoomType.valueOf(typeInput);
            
            String checkInText = readString("Enter check-in date (yyyy-MM-dd): ");
            String checkOutText = readString("Enter check-out date (yyyy-MM-dd): ");
            
            LocalDate checkIn = LocalDate.parse(checkInText, FORMATTER);
            LocalDate checkOut = LocalDate.parse(checkOutText, FORMATTER);
            
            if (checkIn.isBefore(LocalDate.now())) {
                printError("Check-in date cannot be in the past!");
                return;
            }
            
            if (!checkOut.isAfter(checkIn)) {
                printError("Check-out date must be after check-in date!");
                return;
            }
            
            List<Room> available = hotel.findAvailableRoomsByType(type, checkIn, checkOut);
            
            if (available.isEmpty()) {
                printWarning("No rooms available for " + type + " on those dates.");
                return;
            }
            
            System.out.println("\n" + GREEN + "✓ Found " + available.size() + " available room(s):" + RESET);
            System.out.println(BOLD + "┌─────────────┬──────────────┐" + RESET);
            System.out.println(BOLD + "│ Room # │ Price/Night  │" + RESET);
            System.out.println(BOLD + "├─────────────┼──────────────┤" + RESET);
            
            for (Room room : available) {
                System.out.printf(BOLD + "│ %-8d│ $%-11.2f│%s\n", room.getRoomNumber(), room.getPricePerNight(), RESET);
            }
            System.out.println(BOLD + "└─────────────┴──────────────┘" + RESET);
        } catch (Exception e) {
            printError("Invalid input. Please check your entries.");
        }
    }

    private static void addCustomer() {
        printHeader("REGISTER NEW CUSTOMER");
        try {
            String customerId = readString("Enter customer ID (e.g., C-1001): ");
            
            if (hotel.findCustomerById(customerId) != null) {
                printError("Customer ID already exists!");
                return;
            }
            
            String name = readString("Enter full name: ");
            if (name.isEmpty()) {
                printError("Name cannot be empty!");
                return;
            }
            String phone = readString("Enter phone number: ");
            if (!phone.matches("\\+?\\d{7,15}")) {
                printError("Invalid phone number! Must contain 7 to 15 digits.");
                return;
            }
            String email = readString("Enter email address: ");
            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                printError("Invalid email address format!");
                return;
            }
            
            hotel.addCustomer(new Customer(customerId, name, phone, email));
            printSuccess("✓ Customer registered successfully!");
            System.out.println(CYAN + "ID: " + customerId + " | Name: " + name + RESET);
        } catch (Exception e) {
            printError("Invalid input. Please try again.");
        }
    }

    private static void createReservation() {
        printHeader("MAKE A RESERVATION");
        try {
            String customerId = readString("Enter customer ID: ");
            Customer customer = hotel.findCustomerById(customerId);
            
            if (customer == null) {
                printError("Customer not found!");
                return;
            }
            
            System.out.println(CYAN + "Welcome, " + customer.getName() + "!" + RESET);
            
            System.out.println("\n" + BOLD + "Available room types:" + RESET);
            int i = 1;
            for (RoomType type : RoomType.values()) {
                System.out.println("  " + i + ". " + type);
                i++;
            }
            
            String roomTypeInput = readString("Select preferred room type: ").toUpperCase();
            RoomType roomType = RoomType.valueOf(roomTypeInput);
            
            String checkInText = readString("Enter check-in date (yyyy-MM-dd): ");
            String checkOutText = readString("Enter check-out date (yyyy-MM-dd): ");
            
            LocalDate checkIn = LocalDate.parse(checkInText, FORMATTER);
            LocalDate checkOut = LocalDate.parse(checkOutText, FORMATTER);
            
            if (checkIn.isBefore(LocalDate.now())) {
                printError("Check-in date cannot be in the past!");
                return;
            }
            
            if (!checkOut.isAfter(checkIn)) {
                printError("Check-out date must be after check-in date!");
                return;
            }
            
            Room availableRoom = hotel.findAvailableRoom(roomType, checkIn, checkOut);
            if (availableRoom == null) {
                printError("No rooms available for the selected dates and type.");
                return;
            }
            
            Reservation reservation = hotel.createReservation(customer, availableRoom, checkIn, checkOut);
            if (reservation == null) {
                printError("Failed to create reservation.");
                return;
            }
            
            printSuccess("✓ Reservation confirmed!");
            printDivider();
            System.out.println(BOLD + CYAN + "BOOKING CONFIRMATION" + RESET);
            System.out.println(YELLOW + "Reservation ID: " + RESET + reservation.getReservationId());
            System.out.println(YELLOW + "Guest: " + RESET + customer.getName());
            System.out.println(YELLOW + "Room #: " + RESET + availableRoom.getRoomNumber() + " (" + availableRoom.getRoomType() + ")");
            System.out.println(YELLOW + "Check-in: " + RESET + checkIn);
            System.out.println(YELLOW + "Check-out: " + RESET + checkOut);
            System.out.println(YELLOW + "Nights: " + RESET + reservation.getNumberOfNights());
            System.out.println(YELLOW + "Price/Night: " + RESET + "$" + availableRoom.getPricePerNight());
            double total = hotel.calculateBill(reservation);
            System.out.println(BOLD + GREEN + "Total: $" + String.format("%.2f", total) + RESET);
            printDivider();
        } catch (Exception e) {
            printError("Invalid input. Please try again.");
        }
    }

    private static void viewCustomerReservations() {
        printHeader("MY RESERVATIONS");
        try {
            String customerId = readString("Enter your customer ID: ");
            List<Reservation> reservations = hotel.getCustomerReservations(customerId);
            
            if (reservations.isEmpty()) {
                printWarning("No reservations found for this customer.");
                return;
            }
            
            System.out.println(GREEN + "✓ Found " + reservations.size() + " reservation(s):" + RESET);
            printDivider();
            
            for (Reservation res : reservations) {
                String status = "CONFIRMED".equals(res.getStatus()) ? 
                    GREEN + "CONFIRMED" + RESET : RED + "CANCELLED" + RESET;
                System.out.println(BOLD + "Reservation ID: " + CYAN + res.getReservationId() + RESET);
                System.out.println("  Room #: " + res.getRoom().getRoomNumber() + " (" + res.getRoom().getRoomType() + ")");
                System.out.println("  Check-in: " + res.getCheckInDate() + " | Check-out: " + res.getCheckOutDate());
                System.out.println("  Status: " + status);
                System.out.println("  Total Cost: $" + String.format("%.2f", hotel.calculateBill(res)));
                printDivider();
            }
        } catch (Exception e) {
            printError("Invalid input. Please try again.");
        }
    }

    private static void listAllReservations() {
        printHeader("ALL RESERVATIONS");
        List<Reservation> reservations = hotel.getAllReservations();
        
        if (reservations.isEmpty()) {
            printWarning("No reservations found.");
            return;
        }

        System.out.println(BOLD + "┌──────────────┬──────────────┬──────────┬──────────────┬──────────────┐" + RESET);
        System.out.println(BOLD + "│ Res ID    │ Customer │ Room  │ Check-in │ Check-out│" + RESET);
        System.out.println(BOLD + "├──────────────┼──────────────┼──────────┼──────────────┼──────────────┤" + RESET);
        
        for (Reservation res : reservations) {
            String status = "CONFIRMED".equals(res.getStatus()) ? GREEN + "✓" + RESET : RED + "✗" + RESET;
            System.out.printf(BOLD + "│ %s %s │ %-13s│ %-7d│ %s │ %s │%s\n",
                res.getReservationId(), status,
                res.getCustomer().getName().substring(0, Math.min(13, res.getCustomer().getName().length())),
                res.getRoom().getRoomNumber(),
                res.getCheckInDate(), res.getCheckOutDate(), RESET);
        }
        System.out.println(BOLD + "└──────────────┴──────────────┴──────────┴──────────────┴──────────────┘" + RESET);
    }

    private static void cancelReservation() {
        printHeader("CANCEL RESERVATION");
        try {
            String reservationId = readString("Enter reservation ID to cancel: ");
            Reservation reservation = hotel.findReservationById(reservationId);
            
            if (reservation == null) {
                printError("Reservation not found!");
                return;
            }
            
            if ("CANCELLED".equals(reservation.getStatus())) {
                printWarning("This reservation is already cancelled.");
                return;
            }
            
            System.out.println("\n" + YELLOW + "Cancellation Details:" + RESET);
            System.out.println("  Reservation: " + reservation.getReservationId());
            System.out.println("  Customer: " + reservation.getCustomer().getName());
            System.out.println("  Room: #" + reservation.getRoom().getRoomNumber());
            System.out.println("  Dates: " + reservation.getCheckInDate() + " to " + reservation.getCheckOutDate());
            
            String confirm = readString("\nAre you sure? (yes/no): ").toLowerCase();
            if (!confirm.equals("yes")) {
                printWarning("Cancellation aborted.");
                return;
            }
            
            boolean success = hotel.cancelReservation(reservationId);
            if (success) {
                printSuccess("✓ Reservation cancelled successfully!");
            } else {
                printError("Failed to cancel reservation.");
            }
        } catch (Exception e) {
            printError("Invalid input. Please try again.");
        }
    }

    private static void generateBill() {
        printHeader("GENERATE BILL");
        try {
            String reservationId = readString("Enter reservation ID: ");
            Reservation reservation = hotel.findReservationById(reservationId);
            
            if (reservation == null) {
                printError("Reservation not found!");
                return;
            }
            
            double total = hotel.calculateBill(reservation);
            
            printDivider();
            System.out.println(BOLD + CYAN + "     ✨ CELESTIAL HAVEN HOTEL INVOICE ✨" + RESET);
            printDivider();
            System.out.println(YELLOW + "Reservation ID:     " + RESET + reservation.getReservationId());
            System.out.println(YELLOW + "Guest Name:         " + RESET + reservation.getCustomer().getName());
            System.out.println(YELLOW + "Email:              " + RESET + reservation.getCustomer().getEmail());
            System.out.println(YELLOW + "Phone:              " + RESET + reservation.getCustomer().getPhone());
            printDivider();
            System.out.println(YELLOW + "Room Number:        " + RESET + reservation.getRoom().getRoomNumber());
            System.out.println(YELLOW + "Room Type:          " + RESET + reservation.getRoom().getRoomType());
            System.out.println(YELLOW + "Check-in:           " + RESET + reservation.getCheckInDate());
            System.out.println(YELLOW + "Check-out:          " + RESET + reservation.getCheckOutDate());
            System.out.println(YELLOW + "Number of Nights:   " + RESET + reservation.getNumberOfNights());
            printDivider();
            System.out.println(YELLOW + "Price per Night:    " + RESET + "$" + String.format("%.2f", reservation.getRoom().getPricePerNight()));
            System.out.println(BOLD + GREEN + "TOTAL AMOUNT:       $" + String.format("%.2f", total) + RESET);
            System.out.println(YELLOW + "Status:             " + RESET + 
                ("CONFIRMED".equals(reservation.getStatus()) ? GREEN + "CONFIRMED" + RESET : RED + "CANCELLED" + RESET));
            printDivider();
            System.out.println(CYAN + "Thank you for staying at Celestial Haven!" + RESET);
            printDivider();
        } catch (Exception e) {
            printError("Invalid input. Please try again.");
        }
    }

    private static void viewDashboard() {
        printHeader("DASHBOARD & STATISTICS");
        
        int totalRooms = hotel.getTotalRooms();
        int occupiedRooms = hotel.getOccupiedRooms();
        int availableRoomsCount = hotel.getAvailableRoomCount();
        double occupancyRate = hotel.getOccupancyRate();
        double totalRevenue = hotel.getTotalRevenue();
        int activeReservations = hotel.getActiveReservations().size();
        int totalCustomers = hotel.getAllCustomers().size();
        
        printDivider();
        System.out.println(BOLD + CYAN + "ROOM STATISTICS" + RESET);
        System.out.println(YELLOW + "Total Rooms:        " + RESET + GREEN + totalRooms + RESET);
        System.out.println(YELLOW + "Occupied Rooms:     " + RESET + RED + occupiedRooms + RESET);
        System.out.println(YELLOW + "Available Rooms:    " + RESET + GREEN + availableRoomsCount + RESET);
        System.out.println(YELLOW + "Occupancy Rate:     " + RESET + GREEN + String.format("%.1f%%", occupancyRate) + RESET);
        
        printDivider();
        System.out.println(BOLD + CYAN + "RESERVATION STATISTICS" + RESET);
        System.out.println(YELLOW + "Active Reservations:" + RESET + GREEN + " " + activeReservations + RESET);
        System.out.println(YELLOW + "Cancelled:          " + RESET + RED + " " + hotel.getCancelledReservations().size() + RESET);
        System.out.println(YELLOW + "Total Customers:    " + RESET + GREEN + " " + totalCustomers + RESET);
        
        printDivider();
        System.out.println(BOLD + CYAN + "FINANCIAL STATISTICS" + RESET);
        System.out.println(YELLOW + "Total Revenue:      " + RESET + GREEN + "$" + String.format("%.2f", totalRevenue) + RESET);
        
        // Room breakdown
        printDivider();
        System.out.println(BOLD + CYAN + "ROOMS BY TYPE" + RESET);
        for (RoomType type : RoomType.values()) {
            List<Room> roomsByType = hotel.getRoomsByType(type);
            int occupiedByType = (int) roomsByType.stream().filter(r -> !r.isAvailable()).count();
            System.out.println(YELLOW + type + ": " + RESET + occupiedByType + "/" + roomsByType.size() + " occupied");
        }
        printDivider();
    }

    private static void displayGoodbye() {
        clearScreen();
        System.out.println(BOLD + CYAN + "╔══════════════════════════════════════════════════╗" + RESET);
        System.out.println(BOLD + CYAN + "║                                                  ║" + RESET);
        System.out.println(BOLD + CYAN + "║          " + MAGENTA + "Thank you for using our system!" + CYAN + "          ║" + RESET);
        System.out.println(BOLD + CYAN + "║    " + YELLOW + "Until next starlight stay at Celestial Haven!" + CYAN + "    ║" + RESET);
        System.out.println(BOLD + CYAN + "║                                                  ║" + RESET);
        System.out.println(BOLD + CYAN + "╚══════════════════════════════════════════════════╝" + RESET);
        System.out.println();
    }

    // ==================== HELPER METHODS ====================

    private static int readInt(String prompt) {
        try {
            System.out.print(CYAN + prompt + RESET);
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            printError("Please enter a valid number.");
            return readInt(prompt);
        }
    }

    private static double readDouble(String prompt) {
        try {
            System.out.print(CYAN + prompt + RESET);
            return Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            printError("Please enter a valid number.");
            return readDouble(prompt);
        }
    }

    private static String readString(String prompt) {
        System.out.print(CYAN + prompt + RESET);
        return scanner.nextLine().trim();
    }

    // ==================== FORMATTING METHODS ====================

    private static void printHeader(String title) {
        clearScreen();
        System.out.println(BOLD + BLUE + "╔════════════════════════════════════════════════════╗" + RESET);
        String centered = String.format("%" + (30 + title.length() / 2) + "s", title);
        System.out.println(BOLD + BLUE + "║" + RESET + BOLD + CYAN + centered + BOLD + BLUE + " ║" + RESET);
        System.out.println(BOLD + BLUE + "╚════════════════════════════════════════════════════╝" + RESET);
    }

    private static void printDivider() {
        System.out.println(BLUE + "─────────────────────────────────────────────────────" + RESET);
    }

    private static void printSuccess(String message) {
        System.out.println(GREEN + BOLD + message + RESET);
    }

    private static void printError(String message) {
        System.out.println(RED + BOLD + "✗ ERROR: " + message + RESET);
    }

    private static void printWarning(String message) {
        System.out.println(YELLOW + BOLD + "⚠ WARNING: " + message + RESET);
    }

    private static void clearScreen() {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
}
