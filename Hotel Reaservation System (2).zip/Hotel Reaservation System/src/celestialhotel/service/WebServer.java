package celestialhotel.service;

import celestialhotel.model.Customer;
import celestialhotel.model.Reservation;
import celestialhotel.model.Room;
import celestialhotel.model.RoomType;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebServer {
    private final int port;
    private final HotelService hotelService;
    private HttpServer server;

    public WebServer(int port, HotelService hotelService) {
        this.port = port;
        this.hotelService = hotelService;
    }

    public void start() {
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
            server.createContext("/", new StaticFileHandler());
            server.createContext("/api", new ApiHandler(hotelService));
            server.setExecutor(null); // default executor
            server.start();
            System.out.println("✨ Celestial Haven Web Server started at http://localhost:" + port + " ✨");
        } catch (IOException e) {
            System.err.println("Failed to start web server: " + e.getMessage());
        }
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
        }
    }

    // --- Helper to Send HTTP Responses ---
    private static void sendResponse(HttpExchange exchange, int statusCode, String responseText, String contentType) throws IOException {
        byte[] bytes = responseText.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", contentType + "; charset=utf-8");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    // --- Static Files Handler ---
    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "", "text/plain");
                return;
            }

            String path = exchange.getRequestURI().getPath();
            if (path.equals("/")) {
                path = "/index.html";
            }

            // Search in workspace src/resources/web
            Path file = Paths.get("src/resources/web" + path);
            if (!Files.exists(file) || Files.isDirectory(file)) {
                sendResponse(exchange, 404, "File not found: " + path, "text/plain");
                return;
            }

            String mimeType = "text/plain";
            if (path.endsWith(".html")) mimeType = "text/html";
            else if (path.endsWith(".css")) mimeType = "text/css";
            else if (path.endsWith(".js")) mimeType = "application/javascript";
            else if (path.endsWith(".png")) mimeType = "image/png";

            byte[] bytes = Files.readAllBytes(file);
            exchange.getResponseHeaders().set("Content-Type", mimeType);
            exchange.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        }
    }

    // --- API Handlers ---
    static class ApiHandler implements HttpHandler {
        private final HotelService hotel;

        public ApiHandler(HotelService hotel) {
            this.hotel = hotel;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendResponse(exchange, 204, "", "text/plain");
                return;
            }

            String path = exchange.getRequestURI().getPath();
            String method = exchange.getRequestMethod();

            try {
                if (method.equals("GET")) {
                    if (path.equals("/api/rooms")) {
                        handleGetRooms(exchange);
                    } else if (path.equals("/api/customers")) {
                        handleGetCustomers(exchange);
                    } else if (path.equals("/api/reservations")) {
                        handleGetReservations(exchange);
                    } else if (path.equals("/api/dashboard")) {
                        handleGetDashboard(exchange);
                    } else if (path.equals("/api/rooms/available")) {
                        handleGetAvailableRooms(exchange);
                    } else {
                        sendResponse(exchange, 404, "{\"error\":\"Not Found\"}", "application/json");
                    }
                } else if (method.equals("POST")) {
                    String body = readRequestBody(exchange);
                    if (path.equals("/api/customers")) {
                        handlePostCustomer(exchange, body);
                    } else if (path.equals("/api/reservations")) {
                        handlePostReservation(exchange, body);
                    } else if (path.equals("/api/reservations/cancel")) {
                        handlePostCancelReservation(exchange, body);
                    } else {
                        sendResponse(exchange, 404, "{\"error\":\"Not Found\"}", "application/json");
                    }
                } else {
                    sendResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}", "application/json");
                }
            } catch (Exception e) {
                e.printStackTrace();
                sendResponse(exchange, 500, "{\"error\":\"Internal Server Error: " + e.getMessage() + "\"}", "application/json");
            }
        }

        // --- GET Endpoints ---

        private void handleGetRooms(HttpExchange exchange) throws IOException {
            List<Room> rooms = hotel.getAllRooms();
            sendResponse(exchange, 200, roomsToJson(rooms), "application/json");
        }

        private void handleGetCustomers(HttpExchange exchange) throws IOException {
            List<Customer> customers = hotel.getAllCustomers();
            sendResponse(exchange, 200, customersToJson(customers), "application/json");
        }

        private void handleGetReservations(HttpExchange exchange) throws IOException {
            List<Reservation> reservations = hotel.getAllReservations();
            sendResponse(exchange, 200, reservationsToJson(reservations), "application/json");
        }

        private void handleGetDashboard(HttpExchange exchange) throws IOException {
            int totalRooms = hotel.getTotalRooms();
            int occupiedRooms = hotel.getOccupiedRooms();
            int availableRoomsCount = hotel.getAvailableRoomCount();
            double occupancyRate = hotel.getOccupancyRate();
            double totalRevenue = hotel.getTotalRevenue();
            int activeReservations = hotel.getActiveReservations().size();
            int totalCustomers = hotel.getAllCustomers().size();
            int cancelledReservations = hotel.getCancelledReservations().size();

            String json = String.format(
                    "{\"totalRooms\":%d,\"occupiedRooms\":%d,\"availableRooms\":%d,\"occupancyRate\":%.2f,\"totalRevenue\":%.2f,\"activeReservations\":%d,\"cancelledReservations\":%d,\"totalCustomers\":%d}",
                    totalRooms, occupiedRooms, availableRoomsCount, occupancyRate, totalRevenue, activeReservations, cancelledReservations, totalCustomers
            );
            sendResponse(exchange, 200, json, "application/json");
        }

        private void handleGetAvailableRooms(HttpExchange exchange) throws IOException {
            Map<String, String> params = parseQueryParams(exchange.getRequestURI().getQuery());
            String typeInput = params.get("type");
            String checkInText = params.get("checkIn");
            String checkOutText = params.get("checkOut");

            if (typeInput == null || checkInText == null || checkOutText == null) {
                sendResponse(exchange, 400, "{\"error\":\"Missing query parameters type, checkIn, checkOut\"}", "application/json");
                return;
            }

            try {
                RoomType type = RoomType.valueOf(typeInput.toUpperCase());
                LocalDate checkIn = LocalDate.parse(checkInText);
                LocalDate checkOut = LocalDate.parse(checkOutText);

                List<Room> available = hotel.findAvailableRoomsByType(type, checkIn, checkOut);
                sendResponse(exchange, 200, roomsToJson(available), "application/json");
            } catch (Exception e) {
                sendResponse(exchange, 400, "{\"error\":\"Invalid input format\"}", "application/json");
            }
        }

        // --- POST Endpoints ---

        private void handlePostCustomer(HttpExchange exchange, String body) throws IOException {
            String customerId = getJsonField(body, "customerId");
            String name = getJsonField(body, "name");
            String phone = getJsonField(body, "phone");
            String email = getJsonField(body, "email");

            if (customerId == null || customerId.isEmpty() || name == null || name.isEmpty()) {
                sendResponse(exchange, 400, "{\"error\":\"CustomerId and Name are required\"}", "application/json");
                return;
            }

            if (hotel.findCustomerById(customerId) != null) {
                sendResponse(exchange, 400, "{\"error\":\"Customer ID already exists\"}", "application/json");
                return;
            }

            if (!phone.matches("\\+?\\d{7,15}")) {
                sendResponse(exchange, 400, "{\"error\":\"Invalid phone format. Must contain 7 to 15 digits\"}", "application/json");
                return;
            }

            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                sendResponse(exchange, 400, "{\"error\":\"Invalid email format\"}", "application/json");
                return;
            }

            Customer customer = new Customer(customerId, name, phone, email);
            hotel.addCustomer(customer);
            sendResponse(exchange, 201, "{\"success\":true,\"message\":\"Customer registered successfully\"}", "application/json");
        }

        private void handlePostReservation(HttpExchange exchange, String body) throws IOException {
            String customerId = getJsonField(body, "customerId");
            String roomTypeInput = getJsonField(body, "roomType");
            String checkInText = getJsonField(body, "checkIn");
            String checkOutText = getJsonField(body, "checkOut");

            if (customerId == null || roomTypeInput == null || checkInText == null || checkOutText == null) {
                sendResponse(exchange, 400, "{\"error\":\"Missing fields in request body\"}", "application/json");
                return;
            }

            Customer customer = hotel.findCustomerById(customerId);
            if (customer == null) {
                sendResponse(exchange, 404, "{\"error\":\"Customer not found\"}", "application/json");
                return;
            }

            try {
                RoomType roomType = RoomType.valueOf(roomTypeInput.toUpperCase());
                LocalDate checkIn = LocalDate.parse(checkInText);
                LocalDate checkOut = LocalDate.parse(checkOutText);

                if (checkIn.isBefore(LocalDate.now())) {
                    sendResponse(exchange, 400, "{\"error\":\"Check-in date cannot be in the past\"}", "application/json");
                    return;
                }

                if (!checkOut.isAfter(checkIn)) {
                    sendResponse(exchange, 400, "{\"error\":\"Check-out date must be after check-in date\"}", "application/json");
                    return;
                }

                Room room = hotel.findAvailableRoom(roomType, checkIn, checkOut);
                if (room == null) {
                    sendResponse(exchange, 404, "{\"error\":\"No available rooms found of this type for the specified dates\"}", "application/json");
                    return;
                }

                Reservation res = hotel.createReservation(customer, room, checkIn, checkOut);
                if (res == null) {
                    sendResponse(exchange, 500, "{\"error\":\"Failed to create reservation\"}", "application/json");
                    return;
                }

                String json = String.format(
                        "{\"success\":true,\"reservationId\":\"%s\",\"roomNumber\":%d,\"totalPrice\":%.2f}",
                        res.getReservationId(), room.getRoomNumber(), hotel.calculateBill(res)
                );
                sendResponse(exchange, 201, json, "application/json");
            } catch (Exception e) {
                sendResponse(exchange, 400, "{\"error\":\"Invalid dates or room type format\"}", "application/json");
            }
        }

        private void handlePostCancelReservation(HttpExchange exchange, String body) throws IOException {
            String reservationId = getJsonField(body, "reservationId");
            if (reservationId == null || reservationId.isEmpty()) {
                sendResponse(exchange, 400, "{\"error\":\"ReservationId is required\"}", "application/json");
                return;
            }

            boolean success = hotel.cancelReservation(reservationId);
            if (success) {
                sendResponse(exchange, 200, "{\"success\":true,\"message\":\"Reservation cancelled successfully\"}", "application/json");
            } else {
                sendResponse(exchange, 400, "{\"error\":\"Reservation already cancelled or not found\"}", "application/json");
            }
        }

        // --- JSON Helper Parsers and Serializers ---

        private String roomsToJson(List<Room> rooms) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < rooms.size(); i++) {
                if (i > 0) sb.append(",");
                Room r = rooms.get(i);
                sb.append(String.format("{\"roomNumber\":%d,\"roomType\":\"%s\",\"pricePerNight\":%.2f,\"available\":%b}",
                        r.getRoomNumber(), r.getRoomType().name(), r.getPricePerNight(), r.isAvailable()));
            }
            sb.append("]");
            return sb.toString();
        }

        private String customersToJson(List<Customer> list) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(",");
                Customer c = list.get(i);
                sb.append(String.format("{\"customerId\":\"%s\",\"name\":\"%s\",\"phone\":\"%s\",\"email\":\"%s\"}",
                        escapeJson(c.getCustomerId()), escapeJson(c.getName()), escapeJson(c.getPhone()), escapeJson(c.getEmail())));
            }
            sb.append("]");
            return sb.toString();
        }

        private String reservationsToJson(List<Reservation> list) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(",");
                Reservation r = list.get(i);
                double total = hotel.calculateBill(r);
                sb.append(String.format("{\"reservationId\":\"%s\",\"customerId\":\"%s\",\"customerName\":\"%s\",\"roomNumber\":%d,\"roomType\":\"%s\",\"checkInDate\":\"%s\",\"checkOutDate\":\"%s\",\"status\":\"%s\",\"nights\":%d,\"total\":%.2f}",
                        escapeJson(r.getReservationId()),
                        escapeJson(r.getCustomer().getCustomerId()),
                        escapeJson(r.getCustomer().getName()),
                        r.getRoom().getRoomNumber(),
                        r.getRoom().getRoomType().name(),
                        r.getCheckInDate().toString(),
                        r.getCheckOutDate().toString(),
                        escapeJson(r.getStatus()),
                        r.getNumberOfNights(),
                        total));
            }
            sb.append("]");
            return sb.toString();
        }

        private static String escapeJson(String input) {
            if (input == null) return "";
            return input.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r")
                    .replace("\t", "\\t");
        }

        private static String getJsonField(String body, String fieldName) {
            Pattern pattern = Pattern.compile("\"" + fieldName + "\"\\s*:\\s*\"([^\"]*)\"");
            Matcher matcher = pattern.matcher(body);
            if (matcher.find()) {
                return matcher.group(1);
            }
            Pattern numPattern = Pattern.compile("\"" + fieldName + "\"\\s*:\\s*(\\d+)");
            Matcher numMatcher = numPattern.matcher(body);
            if (numMatcher.find()) {
                return numMatcher.group(1);
            }
            return null;
        }

        private static String readRequestBody(HttpExchange exchange) throws IOException {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                return sb.toString();
            }
        }

        private static Map<String, String> parseQueryParams(String query) {
            Map<String, String> params = new HashMap<>();
            if (query == null || query.isEmpty()) return params;
            for (String param : query.split("&")) {
                String[] entry = param.split("=", 2);
                if (entry.length > 0) {
                    String key = URLDecoder.decode(entry[0], StandardCharsets.UTF_8);
                    String val = entry.length > 1 ? URLDecoder.decode(entry[1], StandardCharsets.UTF_8) : "";
                    params.put(key, val);
                }
            }
            return params;
        }
    }
}
