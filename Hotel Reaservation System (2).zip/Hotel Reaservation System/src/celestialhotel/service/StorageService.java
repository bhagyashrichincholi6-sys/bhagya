package celestialhotel.service;

import celestialhotel.model.Customer;
import celestialhotel.model.Reservation;
import celestialhotel.model.Room;
import celestialhotel.model.RoomType;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StorageService {
    private static final String DATA_DIR = "data";
    private static final String ROOMS_FILE = DATA_DIR + "/rooms.csv";
    private static final String CUSTOMERS_FILE = DATA_DIR + "/customers.csv";
    private static final String RESERVATIONS_FILE = DATA_DIR + "/reservations.csv";

    public StorageService() {
        ensureDataDirectoryExists();
    }

    private void ensureDataDirectoryExists() {
        try {
            Path path = Paths.get(DATA_DIR);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
            }
        } catch (IOException e) {
            System.err.println("Failed to create data directory: " + e.getMessage());
        }
    }

    // --- CSV Parsing and Formatting Helpers ---

    private static List<String> parseCsvLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    sb.append('"');
                    i++; // Skip the next quote
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                result.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(c);
            }
        }
        result.add(sb.toString());
        return result;
    }

    private static String toCsvLine(List<String> fields) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < fields.size(); i++) {
            if (i > 0) sb.append(",");
            String field = fields.get(i);
            if (field == null) {
                field = "";
            }
            if (field.contains(",") || field.contains("\"") || field.contains("\n") || field.contains("\r")) {
                sb.append('"').append(field.replace("\"", "\"\"")).append('"');
            } else {
                sb.append(field);
            }
        }
        return sb.toString();
    }

    // --- Rooms Persistence ---

    public List<Room> loadRooms() {
        List<Room> rooms = new ArrayList<>();
        File file = new File(ROOMS_FILE);
        if (!file.exists()) {
            return rooms;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            // Skip header if exists
            boolean isHeader = true;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                List<String> fields = parseCsvLine(line);
                if (fields.size() < 4) continue;

                int roomNumber = Integer.parseInt(fields.get(0).trim());
                RoomType roomType = RoomType.valueOf(fields.get(1).trim().toUpperCase());
                double pricePerNight = Double.parseDouble(fields.get(2).trim());
                boolean available = Boolean.parseBoolean(fields.get(3).trim());

                rooms.add(new Room(roomNumber, roomType, pricePerNight, available));
            }
        } catch (Exception e) {
            System.err.println("Error reading rooms file: " + e.getMessage());
        }
        return rooms;
    }

    public void saveRooms(List<Room> rooms) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ROOMS_FILE))) {
            pw.println("RoomNumber,RoomType,PricePerNight,Available");
            for (Room room : rooms) {
                List<String> fields = List.of(
                        String.valueOf(room.getRoomNumber()),
                        room.getRoomType().name(),
                        String.valueOf(room.getPricePerNight()),
                        String.valueOf(room.isAvailable())
                );
                pw.println(toCsvLine(fields));
            }
        } catch (IOException e) {
            System.err.println("Error writing rooms file: " + e.getMessage());
        }
    }

    // --- Customers Persistence ---

    public List<Customer> loadCustomers() {
        List<Customer> customers = new ArrayList<>();
        File file = new File(CUSTOMERS_FILE);
        if (!file.exists()) {
            return customers;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isHeader = true;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                List<String> fields = parseCsvLine(line);
                if (fields.size() < 4) continue;

                String customerId = fields.get(0);
                String name = fields.get(1);
                String phone = fields.get(2);
                String email = fields.get(3);

                customers.add(new Customer(customerId, name, phone, email));
            }
        } catch (Exception e) {
            System.err.println("Error reading customers file: " + e.getMessage());
        }
        return customers;
    }

    public void saveCustomers(List<Customer> customers) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(CUSTOMERS_FILE))) {
            pw.println("CustomerId,Name,Phone,Email");
            for (Customer customer : customers) {
                List<String> fields = List.of(
                        customer.getCustomerId(),
                        customer.getName(),
                        customer.getPhone(),
                        customer.getEmail()
                );
                pw.println(toCsvLine(fields));
            }
        } catch (IOException e) {
            System.err.println("Error writing customers file: " + e.getMessage());
        }
    }

    // --- Reservations Persistence ---

    public List<Reservation> loadReservations(List<Customer> customers, List<Room> rooms) {
        List<Reservation> reservations = new ArrayList<>();
        File file = new File(RESERVATIONS_FILE);
        if (!file.exists()) {
            return reservations;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            boolean isHeader = true;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                if (isHeader) {
                    isHeader = false;
                    continue;
                }
                List<String> fields = parseCsvLine(line);
                if (fields.size() < 6) continue;

                String reservationId = fields.get(0);
                String customerId = fields.get(1);
                int roomNumber = Integer.parseInt(fields.get(2).trim());
                LocalDate checkInDate = LocalDate.parse(fields.get(3).trim());
                LocalDate checkOutDate = LocalDate.parse(fields.get(4).trim());
                String status = fields.get(5);

                Customer customer = findCustomer(customers, customerId);
                Room room = findRoom(rooms, roomNumber);

                if (customer != null && room != null) {
                    reservations.add(new Reservation(reservationId, customer, room, checkInDate, checkOutDate, status));
                }
            }
        } catch (Exception e) {
            System.err.println("Error reading reservations file: " + e.getMessage());
        }
        return reservations;
    }

    public void saveReservations(List<Reservation> reservations) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(RESERVATIONS_FILE))) {
            pw.println("ReservationId,CustomerId,RoomNumber,CheckInDate,CheckOutDate,Status");
            for (Reservation res : reservations) {
                List<String> fields = List.of(
                        res.getReservationId(),
                        res.getCustomer().getCustomerId(),
                        String.valueOf(res.getRoom().getRoomNumber()),
                        res.getCheckInDate().toString(),
                        res.getCheckOutDate().toString(),
                        res.getStatus()
                );
                pw.println(toCsvLine(fields));
            }
        } catch (IOException e) {
            System.err.println("Error writing reservations file: " + e.getMessage());
        }
    }

    // Helper lookups for deserialization links
    private Customer findCustomer(List<Customer> list, String customerId) {
        for (Customer c : list) {
            if (c.getCustomerId().equalsIgnoreCase(customerId)) {
                return c;
            }
        }
        return null;
    }

    private Room findRoom(List<Room> list, int roomNumber) {
        for (Room r : list) {
            if (r.getRoomNumber() == roomNumber) {
                return r;
            }
        }
        return null;
    }
}
