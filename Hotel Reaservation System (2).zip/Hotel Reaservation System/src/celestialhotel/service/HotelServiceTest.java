package celestialhotel.service;

import celestialhotel.model.Customer;
import celestialhotel.model.Reservation;
import celestialhotel.model.Room;
import celestialhotel.model.RoomType;

import java.io.File;
import java.time.LocalDate;
import java.util.List;

public class HotelServiceTest {

    public static void main(String[] args) {
        System.out.println("Running HotelService tests...");
        
        // Use temporary data folder for testing to avoid overwriting production data
        // In this simple test, we run against the standard service which loads/saves to data folder.
        // We will clean up test data files after test runs or run with dummy files.
        try {
            cleanupTestData();

            testAddRoom();
            testAddCustomer();
            testCreateReservation();
            testDoubleBookingPrevention();
            testCalculateBill();
            testCancelReservation();

            System.out.println("\nAll tests PASSED successfully!");
        } catch (AssertionError e) {
            System.err.println("\nTest FAILED: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cleanupTestData();
        }
    }

    private static void cleanupTestData() {
        // Delete data files to ensure a clean state
        File rooms = new File("data/rooms.csv");
        File customers = new File("data/customers.csv");
        File reservations = new File("data/reservations.csv");
        if (rooms.exists()) rooms.delete();
        if (customers.exists()) customers.delete();
        if (reservations.exists()) reservations.delete();
    }

    private static void testAddRoom() {
        HotelService service = new HotelService();
        Room room = new Room(999, RoomType.SUITE, 300.0, true);
        service.addRoom(room);

        Room retrieved = service.findRoomByNumber(999);
        assert retrieved != null : "Room 999 should have been added";
        assert retrieved.getRoomType() == RoomType.SUITE : "Room type should be SUITE";
        assert retrieved.getPricePerNight() == 300.0 : "Room price should be 300.0";

        // Try adding duplicate
        service.addRoom(new Room(999, RoomType.STANDARD, 100.0, true));
        assert service.findRoomByNumber(999).getRoomType() == RoomType.SUITE : "Duplicate room insertion should be ignored";
        System.out.println("✓ testAddRoom passed");
    }

    private static void testAddCustomer() {
        HotelService service = new HotelService();
        Customer customer = new Customer("T-100", "Test Guest", "1234567890", "test@test.com");
        service.addCustomer(customer);

        Customer retrieved = service.findCustomerById("T-100");
        assert retrieved != null : "Customer T-100 should have been added";
        assert retrieved.getName().equals("Test Guest") : "Customer name mismatch";

        // Duplicate checks
        service.addCustomer(new Customer("T-100", "Another Name", "0987654321", "another@test.com"));
        assert service.findCustomerById("T-100").getName().equals("Test Guest") : "Duplicate customer ID insertion should be ignored";
        System.out.println("✓ testAddCustomer passed");
    }

    private static void testCreateReservation() {
        HotelService service = new HotelService();
        Room room = new Room(901, RoomType.STANDARD, 100.0, true);
        Customer customer = new Customer("T-200", "Booking Guest", "9999", "book@test.com");
        service.addRoom(room);
        service.addCustomer(customer);

        LocalDate checkIn = LocalDate.now();
        LocalDate checkOut = checkIn.plusDays(3);

        Reservation res = service.createReservation(customer, room, checkIn, checkOut);
        assert res != null : "Reservation creation failed";
        assert res.getCustomer().getCustomerId().equals("T-200") : "Reservation customer ID mismatch";
        assert res.getRoom().getRoomNumber() == 901 : "Reservation room mismatch";
        assert res.getNumberOfNights() == 3 : "Reservation night calculation mismatch";
        assert !room.isAvailable() : "Room availability status should be set to occupied (false)";
        System.out.println("✓ testCreateReservation passed");
    }

    private static void testDoubleBookingPrevention() {
        HotelService service = new HotelService();
        Room room = new Room(902, RoomType.DELUXE, 150.0, true);
        Customer customer1 = new Customer("T-301", "Guest A", "111", "a@test.com");
        Customer customer2 = new Customer("T-302", "Guest B", "222", "b@test.com");
        service.addRoom(room);
        service.addCustomer(customer1);
        service.addCustomer(customer2);

        LocalDate start1 = LocalDate.of(2026, 9, 1);
        LocalDate end1 = LocalDate.of(2026, 9, 5);

        // First reservation
        Reservation res1 = service.createReservation(customer1, room, start1, end1);
        assert res1 != null : "First reservation failed";

        // Try booking overlapping dates: Sept 3 to Sept 7
        LocalDate start2 = LocalDate.of(2026, 9, 3);
        LocalDate end2 = LocalDate.of(2026, 9, 7);

        Room availableRoom = service.findAvailableRoom(RoomType.DELUXE, start2, end2);
        assert availableRoom == null : "Room should not be available due to overlap";

        // Try booking non-overlapping dates: Sept 5 to Sept 10
        LocalDate start3 = LocalDate.of(2026, 9, 5);
        LocalDate end3 = LocalDate.of(2026, 9, 10);

        Room availableRoom2 = service.findAvailableRoom(RoomType.DELUXE, start3, end3);
        assert availableRoom2 != null && availableRoom2.getRoomNumber() == 902 : "Room should be available since Sept 5 checkout matches Sept 5 checkin";
        System.out.println("✓ testDoubleBookingPrevention passed");
    }

    private static void testCalculateBill() {
        HotelService service = new HotelService();
        Room room = new Room(903, RoomType.FAMILY, 200.0, true);
        Customer customer = new Customer("T-400", "Billing Guest", "444", "c@test.com");
        service.addRoom(room);
        service.addCustomer(customer);

        LocalDate checkIn = LocalDate.of(2026, 10, 1);
        LocalDate checkOut = LocalDate.of(2026, 10, 5); // 4 nights

        Reservation res = service.createReservation(customer, room, checkIn, checkOut);
        double expectedBill = 4 * 200.0;
        double calculatedBill = service.calculateBill(res);
        assert calculatedBill == expectedBill : "Expected bill: " + expectedBill + ", but got: " + calculatedBill;
        System.out.println("✓ testCalculateBill passed");
    }

    private static void testCancelReservation() {
        HotelService service = new HotelService();
        Room room = new Room(904, RoomType.STANDARD, 80.0, true);
        Customer customer = new Customer("T-500", "Cancelling Guest", "555", "d@test.com");
        service.addRoom(room);
        service.addCustomer(customer);

        LocalDate checkIn = LocalDate.now();
        LocalDate checkOut = checkIn.plusDays(2);

        Reservation res = service.createReservation(customer, room, checkIn, checkOut);
        assert !room.isAvailable() : "Room should be occupied";

        boolean cancelSuccess = service.cancelReservation(res.getReservationId());
        assert cancelSuccess : "Cancellation should succeed";
        assert "CANCELLED".equals(res.getStatus()) : "Reservation status should be CANCELLED";
        assert room.isAvailable() : "Room should be available after cancellation";
        System.out.println("✓ testCancelReservation passed");
    }
}
