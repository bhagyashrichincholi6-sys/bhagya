package celestialhotel.service;

import celestialhotel.model.Customer;
import celestialhotel.model.Reservation;
import celestialhotel.model.Room;
import celestialhotel.model.RoomType;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class HotelService {
    private final StorageService storageService = new StorageService();
    private final List<Room> rooms;
    private final List<Customer> customers;
    private final List<Reservation> reservations;

    public HotelService() {
        this.rooms = storageService.loadRooms();
        this.customers = storageService.loadCustomers();
        this.reservations = storageService.loadReservations(this.customers, this.rooms);
    }

    // Room Management
    public void addRoom(Room room) {
        if (room != null && findRoomByNumber(room.getRoomNumber()) == null) {
            rooms.add(room);
            storageService.saveRooms(rooms);
        }
    }

    public List<Room> getAllRooms() {
        return new ArrayList<>(rooms);
    }

    public List<Room> getAvailableRooms() {
        return rooms.stream()
                .filter(Room::isAvailable)
                .collect(Collectors.toList());
    }

    public List<Room> getRoomsByType(RoomType roomType) {
        return rooms.stream()
                .filter(room -> room.getRoomType() == roomType)
                .collect(Collectors.toList());
    }

    public Room findRoomByNumber(int roomNumber) {
        for (Room room : rooms) {
            if (room.getRoomNumber() == roomNumber) {
                return room;
            }
        }
        return null;
    }

    // Customer Management
    public void addCustomer(Customer customer) {
        if (customer != null && findCustomerById(customer.getCustomerId()) == null) {
            customers.add(customer);
            storageService.saveCustomers(customers);
        }
    }

    public List<Customer> getAllCustomers() {
        return new ArrayList<>(customers);
    }

    public Customer findCustomerById(String customerId) {
        if (customerId == null || customerId.isEmpty()) {
            return null;
        }
        for (Customer customer : customers) {
            if (customer.getCustomerId().equalsIgnoreCase(customerId)) {
                return customer;
            }
        }
        return null;
    }

    public List<Reservation> getCustomerReservations(String customerId) {
        return reservations.stream()
                .filter(res -> res.getCustomer().getCustomerId().equalsIgnoreCase(customerId))
                .collect(Collectors.toList());
    }

    // Reservation Management
    public Reservation createReservation(Customer customer, Room room, LocalDate checkInDate, LocalDate checkOutDate) {
        if (customer == null || room == null || checkInDate == null || checkOutDate == null) {
            return null;
        }
        if (!checkOutDate.isAfter(checkInDate)) {
            return null;
        }

        String reservationId = "RES-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Reservation reservation = new Reservation(reservationId, customer, room, checkInDate, checkOutDate, "CONFIRMED");
        reservations.add(reservation);
        room.setAvailable(false);
        storageService.saveReservations(reservations);
        storageService.saveRooms(rooms);
        return reservation;
    }

    public List<Reservation> getAllReservations() {
        return new ArrayList<>(reservations);
    }

    public Reservation findReservationById(String reservationId) {
        if (reservationId == null || reservationId.isEmpty()) {
            return null;
        }
        for (Reservation reservation : reservations) {
            if (reservation.getReservationId().equalsIgnoreCase(reservationId)) {
                return reservation;
            }
        }
        return null;
    }

    public List<Reservation> getActiveReservations() {
        return reservations.stream()
                .filter(res -> "CONFIRMED".equals(res.getStatus()))
                .collect(Collectors.toList());
    }

    public List<Reservation> getCancelledReservations() {
        return reservations.stream()
                .filter(res -> "CANCELLED".equals(res.getStatus()))
                .collect(Collectors.toList());
    }

    public boolean cancelReservation(String reservationId) {
        Reservation reservation = findReservationById(reservationId);
        if (reservation == null || "CANCELLED".equals(reservation.getStatus())) {
            return false;
        }

        reservation.setStatus("CANCELLED");
        reservation.getRoom().setAvailable(true);
        storageService.saveReservations(reservations);
        storageService.saveRooms(rooms);
        return true;
    }

    // Billing & Calculations
    public double calculateBill(Reservation reservation) {
        if (reservation == null) {
            return 0;
        }
        long nights = reservation.getNumberOfNights();
        return nights * reservation.getRoom().getPricePerNight();
    }

    public double getTotalRevenue() {
        return reservations.stream()
                .filter(res -> "CONFIRMED".equals(res.getStatus()))
                .mapToDouble(this::calculateBill)
                .sum();
    }

    // Availability Checking
    public Room findAvailableRoom(RoomType roomType, LocalDate checkInDate, LocalDate checkOutDate) {
        if (roomType == null || checkInDate == null || checkOutDate == null) {
            return null;
        }
        
        for (Room room : rooms) {
            if (room.getRoomType() != roomType || !isRoomAvailable(room, checkInDate, checkOutDate)) {
                continue;
            }
            return room;
        }
        return null;
    }

    public List<Room> findAvailableRoomsByType(RoomType roomType, LocalDate checkInDate, LocalDate checkOutDate) {
        return rooms.stream()
                .filter(room -> room.getRoomType() == roomType && isRoomAvailable(room, checkInDate, checkOutDate))
                .collect(Collectors.toList());
    }

    private boolean isRoomAvailable(Room room, LocalDate checkInDate, LocalDate checkOutDate) {
        for (Reservation reservation : reservations) {
            if (reservation.getRoom().getRoomNumber() == room.getRoomNumber() &&
                    "CONFIRMED".equals(reservation.getStatus()) &&
                    checkInDate.isBefore(reservation.getCheckOutDate()) &&
                    checkOutDate.isAfter(reservation.getCheckInDate())) {
                return false;
            }
        }
        return true;
    }

    // Occupancy & Analytics
    public int getTotalRooms() {
        return rooms.size();
    }

    public int getOccupiedRooms() {
        return (int) rooms.stream().filter(room -> !room.isAvailable()).count();
    }

    public int getAvailableRoomCount() {
        return (int) rooms.stream().filter(Room::isAvailable).count();
    }

    public double getOccupancyRate() {
        if (rooms.isEmpty()) {
            return 0;
        }
        return (getOccupiedRooms() * 100.0) / getTotalRooms();
    }
}
