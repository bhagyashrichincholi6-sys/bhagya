document.addEventListener('DOMContentLoaded', () => {
    // Navigation Routing
    const navItems = document.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.content-section');
    const sectionTitle = document.getElementById('section-title');

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSection = item.getAttribute('data-target');

            // Toggle active menu class
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            // Toggle active content section
            sections.forEach(sec => sec.classList.remove('active'));
            document.getElementById(targetSection).classList.add('active');

            // Update title
            sectionTitle.textContent = item.textContent.trim();

            // Refresh section data
            refreshSectionData(targetSection);
        });
    });

    // Form Event Listeners
    document.getElementById('register-guest-form').addEventListener('submit', handleRegisterGuest);
    document.getElementById('book-room-form').addEventListener('submit', handleCreateReservation);

    // Initial load
    initApp();
});

// App Initialization
function initApp() {
    refreshSectionData('dashboard-section');
    setupDateInputs();
    
    // Automatically poll dashboard stats every 15s
    setInterval(() => {
        if (document.getElementById('dashboard-section').classList.contains('active')) {
            loadDashboardStats();
        }
    }, 15000);
}

// Set min dates to today
function setupDateInputs() {
    const todayStr = new Date().toISOString().split('T')[0];
    const checkinInput = document.getElementById('booking-checkin');
    const checkoutInput = document.getElementById('booking-checkout');
    
    if (checkinInput && checkoutInput) {
        checkinInput.setAttribute('min', todayStr);
        checkinInput.addEventListener('change', () => {
            // Set checkout min to checkin date + 1 day
            const checkinVal = checkinInput.value;
            if (checkinVal) {
                const nextDay = new Date(checkinVal);
                nextDay.setDate(nextDay.getDate() + 1);
                checkoutInput.setAttribute('min', nextDay.toISOString().split('T')[0]);
            }
        });
    }
}

// Router Refresh Controller
function refreshSectionData(sectionId) {
    hideAlert();
    switch (sectionId) {
        case 'dashboard-section':
            loadDashboardStats();
            break;
        case 'rooms-section':
            loadRooms();
            break;
        case 'guests-section':
            loadGuests();
            break;
        case 'booking-section':
            populateGuestSelect();
            break;
        case 'reservations-list-section':
            loadReservations();
            break;
    }
}

// --- Notifications ---
function showAlert(message, isSuccess = false) {
    const banner = document.getElementById('alert-banner');
    const textSpan = document.getElementById('alert-message');
    
    banner.className = `alert ${isSuccess ? 'success' : ''}`;
    textSpan.textContent = message;
    
    // Auto scroll to top to see banner
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function hideAlert() {
    const banner = document.getElementById('alert-banner');
    if (banner) {
        banner.classList.add('hidden');
    }
}

// --- API Calls & Data Rendering ---

// 1. Load Dashboard
function loadDashboardStats() {
    fetch('/api/dashboard')
        .then(res => res.json())
        .then(data => {
            document.getElementById('stat-revenue').textContent = `$${data.totalRevenue.toFixed(2)}`;
            document.getElementById('stat-occupancy').textContent = `${data.occupancyRate.toFixed(1)}%`;
            document.getElementById('stat-rooms-avail').textContent = `${data.availableRooms}/${data.totalRooms}`;
            document.getElementById('stat-bookings').textContent = data.activeReservations;
            document.getElementById('summary-guests-count').textContent = data.totalCustomers;
            document.getElementById('summary-cancelled-count').textContent = data.cancelledReservations;
        })
        .catch(err => {
            console.error('Failed to load dashboard:', err);
            showAlert('Systems failure: unable to retrieve system dashboard telemetry.');
        });
}

// 2. Load Rooms list
function loadRooms() {
    const container = document.getElementById('rooms-container');
    container.innerHTML = '<div class="loading">Querying system grid...</div>';

    fetch('/api/rooms')
        .then(res => res.json())
        .then(rooms => {
            container.innerHTML = '';
            if (rooms.length === 0) {
                container.innerHTML = '<div class="loading">No stellar units configured.</div>';
                return;
            }
            rooms.forEach(room => {
                const card = document.createElement('div');
                card.className = `room-card ${room.available ? '' : 'occupied'}`;
                
                const statusHtml = room.available 
                    ? `<span class="room-status status-avail"><span class="status-dot"></span>AVAILABLE</span>`
                    : `<span class="room-status status-occ"><span class="status-dot"></span>OCCUPIED</span>`;

                card.innerHTML = `
                    <div class="room-header">
                        <span class="room-number">Suite #${room.roomNumber}</span>
                        <span class="room-type-badge">${room.roomType}</span>
                    </div>
                    <div class="room-body">
                        <div class="room-price">$${room.pricePerNight.toFixed(2)} <span>/ night</span></div>
                        ${statusHtml}
                    </div>
                `;
                container.appendChild(card);
            });
        })
        .catch(err => {
            console.error('Failed to load rooms:', err);
            container.innerHTML = '<div class="loading text-danger">Data link connection failed.</div>';
        });
}

// 3. Load Guests
function loadGuests() {
    const tbody = document.getElementById('guests-table-body');
    tbody.innerHTML = '<tr><td colspan="4" class="text-center">Linking database...</td></tr>';

    fetch('/api/customers')
        .then(res => res.json())
        .then(guests => {
            tbody.innerHTML = '';
            if (guests.length === 0) {
                tbody.innerHTML = '<tr><td colspan="4" class="text-center">No space explorers registered yet.</td></tr>';
                return;
            }
            guests.forEach(g => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong>${escapeHtml(g.customerId)}</strong></td>
                    <td>${escapeHtml(g.name)}</td>
                    <td>${escapeHtml(g.phone)}</td>
                    <td><a href="mailto:${escapeHtml(g.email)}" style="color: #66FCF1;">${escapeHtml(g.email)}</a></td>
                `;
                tbody.appendChild(tr);
            });
        })
        .catch(err => {
            console.error('Failed to load guests:', err);
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Telemetry error linking guest list.</td></tr>';
        });
}

// Populate guest select list in booking form
function populateGuestSelect() {
    const select = document.getElementById('booking-guest');
    select.innerHTML = '<option value="" disabled selected>Loading Space Explorers...</option>';

    fetch('/api/customers')
        .then(res => res.json())
        .then(guests => {
            select.innerHTML = '<option value="" disabled selected>-- Select Space Explorer --</option>';
            if (guests.length === 0) {
                select.innerHTML = '<option value="" disabled>No guests registered. Please register a guest first.</option>';
                return;
            }
            guests.forEach(g => {
                const opt = document.createElement('option');
                opt.value = g.customerId;
                opt.textContent = `${g.name} (${g.customerId})`;
                select.appendChild(opt);
            });
        })
        .catch(err => {
            console.error('Failed to populate guests drop list:', err);
            select.innerHTML = '<option value="" disabled>Error loading guests list</option>';
        });
}

// 4. Load Reservations list
function loadReservations() {
    const tbody = document.getElementById('reservations-table-body');
    tbody.innerHTML = '<tr><td colspan="9" class="text-center">Connecting telemetry logbook...</td></tr>';

    fetch('/api/reservations')
        .then(res => res.json())
        .then(reservations => {
            tbody.innerHTML = '';
            if (reservations.length === 0) {
                tbody.innerHTML = '<tr><td colspan="9" class="text-center">Stellar logbook is currently empty.</td></tr>';
                return;
            }
            reservations.forEach(r => {
                const isConfirmed = r.status === 'CONFIRMED';
                const badgeClass = isConfirmed ? 'badge-confirmed' : 'badge-cancelled';
                const controlButton = isConfirmed 
                    ? `<button class="btn btn-danger" onclick="cancelReservation('${r.reservationId}')">Abort Booking</button>`
                    : `<span style="color: #5b6877; font-style: italic;">No Action</span>`;

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong>${escapeHtml(r.reservationId)}</strong></td>
                    <td>${escapeHtml(r.customerName)} <span style="font-size: 0.8rem; color:#8f9aa9;">(${escapeHtml(r.customerId)})</span></td>
                    <td>Suite #${r.roomNumber}</td>
                    <td><span class="room-type-badge">${r.roomType}</span></td>
                    <td>${r.checkInDate}</td>
                    <td>${r.checkOutDate}</td>
                    <td style="color:#FFD700; font-weight:700;">$${r.total.toFixed(2)}</td>
                    <td><span class="badge ${badgeClass}">${r.status}</span></td>
                    <td>${controlButton}</td>
                `;
                tbody.appendChild(tr);
            });
        })
        .catch(err => {
            console.error('Failed to load reservations:', err);
            tbody.innerHTML = '<tr><td colspan="9" class="text-center text-danger">Failed to download reservations registry log.</td></tr>';
        });
}

// --- Submit Handlers ---

// Submit guest registration
function handleRegisterGuest(e) {
    e.preventDefault();
    hideAlert();

    const customerId = document.getElementById('guest-id').value.trim();
    const name = document.getElementById('guest-name').value.trim();
    const phone = document.getElementById('guest-phone').value.trim();
    const email = document.getElementById('guest-email').value.trim();

    const payload = { customerId, name, phone, email };

    fetch('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showAlert(`Explorer ${name} registered successfully! Registry entry confirmed.`, true);
            document.getElementById('register-guest-form').reset();
            loadGuests();
        } else {
            showAlert(`Registry Rejected: ${data.error || 'Invalid configuration payload'}`);
        }
    })
    .catch(err => {
        console.error('Failed to register guest:', err);
        showAlert('Grid connection failure: registry transmission failed.');
    });
}

// Submit reservation
function handleCreateReservation(e) {
    e.preventDefault();
    hideAlert();

    const customerId = document.getElementById('booking-guest').value;
    const roomType = document.getElementById('booking-room-type').value;
    const checkIn = document.getElementById('booking-checkin').value;
    const checkOut = document.getElementById('booking-checkout').value;

    const payload = { customerId, roomType, checkIn, checkOut };

    fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showAlert(`Hyper-jump reservation confirmed! Booking ID: ${data.reservationId}. Room Assigned: Suite #${data.roomNumber}. Charged: $${data.totalPrice.toFixed(2)}.`, true);
            document.getElementById('book-room-form').reset();
            setupDateInputs();
        } else {
            showAlert(`Booking Aborted: ${data.error || 'Dates overlap or room type unavailable.'}`);
        }
    })
    .catch(err => {
        console.error('Failed to make reservation:', err);
        showAlert('Grid booking transmission failure.');
    });
}

// Cancel reservation action
function cancelReservation(reservationId) {
    if (!confirm(`Are you absolutely sure you want to abort booking ${reservationId}?`)) {
        return;
    }
    hideAlert();

    fetch('/api/reservations/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reservationId })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            showAlert(`Booking aborted successfully! Reservation ${reservationId} is now CANCELLED.`, true);
            loadReservations();
        } else {
            showAlert(`Abort Command Failed: ${data.error}`);
        }
    })
    .catch(err => {
        console.error('Failed to cancel reservation:', err);
        showAlert('Abort booking command transmission error.');
    });
}

// Escape Helper to prevent XSS in dynamic outputs
function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;")
              .replace(/"/g, "&quot;")
              .replace(/'/g, "&#039;");
}

// Real-time sync utilities
function startDataSync() {
    // Sync every 30 seconds if app is active
    setInterval(() => {
        if (document.hidden) return;
        const activeSection = document.querySelector('.content-section.active');
        if (activeSection) {
            const sectionId = activeSection.id;
            if (sectionId === 'dashboard-section') {
                loadDashboardStats();
            } else if (sectionId === 'reservations-list-section') {
                loadReservations();
            }
        }
    }, 30000);
}

// Initialize real-time sync on load
startDataSync();
