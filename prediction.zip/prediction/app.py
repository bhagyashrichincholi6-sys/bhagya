from flask import Flask, flash, render_template, request, redirect, url_for,session
from database import db, Employee, PasswordRecoveryRequest, Task, WorkUpdate
import joblib
import numpy as np
from datetime import date, datetime, timedelta
from sqlalchemy import inspect, text
app = Flask(__name__)


def get_task_timeline_status(task):
    """Return a warning object for deadline tracking."""

    if task.status and task.status.lower() == "completed":
        return {
            "label": "Completed",
            "warning": False,
            "message": "Task completed successfully."
        }

    if not task.deadline:
        return {
            "label": "No deadline",
            "warning": False,
            "message": "No deadline has been set for this task."
        }

    try:
        deadline = datetime.strptime(task.deadline, "%Y-%m-%d").date()
    except ValueError:
        return {
            "label": "Check deadline",
            "warning": False,
            "message": "Deadline format is invalid."
        }

    today = date.today()

    if deadline < today:
        return {
            "label": "Late",
            "warning": True,
            "message": f"Deadline missed by {(today - deadline).days} day(s)."
        }

    if deadline == today:
        return {
            "label": "Due today",
            "warning": True,
            "message": "This task is due today."
        }

    days_left = (deadline - today).days

    if days_left <= 2:
        return {
            "label": "Due soon",
            "warning": True,
            "message": f"Only {days_left} day(s) left before the deadline."
        }

    return {
        "label": "On track",
        "warning": False,
        "message": "Task is still within the expected timeline."
    }


def build_improvement_recommendations(updates):
    """Create explainable improvement suggestions from recorded work signals."""

    scored_updates = [
        update for update in updates
        if update.performance_score is not None
    ]
    if not scored_updates:
        return []

    recent_updates = scored_updates[:5]
    completion_updates = [
        update for update in recent_updates
        if update.completion is not None
    ]
    average_score = sum(
        update.performance_score for update in recent_updates
    ) / len(recent_updates)
    average_completion = sum(
        update.completion for update in completion_updates
    ) / len(completion_updates) if completion_updates else 0
    absent_updates = [
        update for update in recent_updates
        if (update.attendance or "").lower() == "absent"
    ]
    high_risk_updates = [
        update for update in recent_updates
        if (update.risk_level or "").lower() == "high"
    ]
    recommendations = []

    if absent_updates:
        recommendations.append({
            "priority": "High",
            "title": "Stabilize attendance",
            "why": f"{len(absent_updates)} of your last {len(recent_updates)} updates recorded an absence, which reduces the performance score.",
            "action": "Plan coverage early and notify your manager as soon as an absence is expected."
        })

    if average_completion < 80:
        recommendations.append({
            "priority": "Medium",
            "title": "Raise task completion",
            "why": f"Your recent average completion is {average_completion:.0f}%, leaving the largest measurable gap in your score.",
            "action": "Break the next task into daily milestones and confirm the next milestone before starting new work."
        })

    if len(scored_updates) >= 6:
        latest_average = sum(
            update.performance_score for update in scored_updates[:3]
        ) / 3
        previous_average = sum(
            update.performance_score for update in scored_updates[3:6]
        ) / 3
        if latest_average < previous_average - 5:
            recommendations.append({
                "priority": "High",
                "title": "Reverse the recent decline",
                "why": f"Your latest three updates average {latest_average:.0f}%, down from {previous_average:.0f}% in the three updates before them.",
                "action": "Review the last two delayed tasks with your manager and agree on one smaller, achievable target for the next update."
            })
        elif latest_average > previous_average + 5:
            recommendations.append({
                "priority": "Low",
                "title": "Repeat what is working",
                "why": f"Your latest three updates average {latest_average:.0f}%, up from {previous_average:.0f}% previously.",
                "action": "Keep the same planning rhythm and document the habits that helped you sustain this improvement."
            })

    if high_risk_updates and not any(
        recommendation["title"] == "Reverse the recent decline"
        for recommendation in recommendations
    ):
        recommendations.append({
            "priority": "High",
            "title": "Address high-risk work early",
            "why": f"The model marked {len(high_risk_updates)} of your last {len(recent_updates)} updates as high risk.",
            "action": "Raise blockers in your next check-in and request help before the deadline is at risk."
        })

    if not recommendations and average_score >= 80:
        recommendations.append({
            "priority": "Low",
            "title": "Maintain your current pace",
            "why": f"Your last {len(recent_updates)} updates average {average_score:.0f}%, with no major improvement signal detected.",
            "action": "Continue your current routine and set one stretch goal for the next task."
        })

    return recommendations[:3]


def calculate_improvement_score(updates):
    """Return a 0-100 index comparing recent performance with the prior period."""

    scored_updates = [
        update for update in updates
        if update.performance_score is not None
    ]
    if len(scored_updates) < 2:
        return None

    period_size = min(3, len(scored_updates) // 2)
    recent_average = sum(
        update.performance_score for update in scored_updates[:period_size]
    ) / period_size
    previous_average = sum(
        update.performance_score
        for update in scored_updates[period_size:period_size * 2]
    ) / period_size
    improvement_delta = recent_average - previous_average

    return round(max(0, min(100, 50 + improvement_delta * 5)))

app.secret_key = "workforce123"

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///workforce.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)


# --------------------------------------------------
# LOAD ML MODEL
# --------------------------------------------------

try:
    model = joblib.load("performance_model.pkl")
except Exception:
    model = None


# --------------------------------------------------
# CREATE DATABASE TABLES
# --------------------------------------------------

with app.app_context():
    db.create_all()

    # Keep existing SQLite databases compatible with the timestamped updates.
    work_update_columns = {
        column["name"]
        for column in inspect(db.engine).get_columns("work_updates")
    }
    if "created_at" not in work_update_columns:
        with db.engine.begin() as connection:
            connection.execute(
                text("ALTER TABLE work_updates ADD COLUMN created_at DATETIME")
            )

@app.route("/view_updates")
def view_updates():

    # Allow both HR and employees
    if "employee" not in session and not session.get("hr"):
        return redirect(url_for("login"))

    # If HR, show all updates
    if session.get("hr"):
        all_updates = WorkUpdate.query.order_by(WorkUpdate.id.desc()).all()
        return render_template(
            "view_updates.html",
            updates=all_updates,
            employee=None,
            is_hr=True
        )

    # If employee, show only their updates
    employee = session["employee"]

    employee_id = employee["id"]

    updates = WorkUpdate.query.filter_by(
        employee_id=employee_id
    ).order_by(
        WorkUpdate.id.desc()
    ).all()

    return render_template(
        "view_updates.html",
        updates=updates,
        employee=employee,
        is_hr=False
    )


# ==================================================
# LOGIN
# ==================================================

@app.route("/", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get("email", "").strip()
        password = request.form.get("password", "").strip()

        # -----------------------------
        # HR LOGIN
        # -----------------------------

        if email == "hr@company.com" and password == "admin":

            session.clear()

            session["hr"] = True
            session["role"] = "HR"
            session.modified = True

            return redirect("/hr")

        # -----------------------------
        # EMPLOYEE LOGIN
        # -----------------------------

        employee = Employee.query.filter_by(
            email=email,
            password=password
        ).first()

        if employee:

            session.clear()

            session["employee"] = {
                "id": employee.id,
                "name": employee.name,
                "email": employee.email
            }

            session["role"] = "employee"
            session.modified = True

            return redirect("/employee")

        return render_template(
            "login.html",
            error="Invalid email or password"
        )

    return render_template("login.html")


@app.route("/forgot_password", methods=["GET", "POST"])
def forgot_password():

    if request.method == "POST":
        email = request.form.get("email", "").strip()
        employee = Employee.query.filter_by(email=email).first()

        if employee:
            pending_request = PasswordRecoveryRequest.query.filter_by(
                employee_id=employee.id,
                status="Pending"
            ).first()

            if not pending_request:
                db.session.add(
                    PasswordRecoveryRequest(employee_id=employee.id)
                )
                db.session.commit()

        return render_template(
            "forgot_password.html",
            message="Your request was sent to HR. Please contact HR to receive your new password."
        )

    return render_template("forgot_password.html")


# ==================================================
# HR DASHBOARD
# ==================================================

@app.route("/hr")
def hr_dashboard():

    if not session.get("hr"):
        return redirect("/")

    employees = Employee.query.all()
    tasks = Task.query.all()

    total_employees = Employee.query.count()
    total_tasks = Task.query.count()
    total_updates = WorkUpdate.query.count()

    high_risk = WorkUpdate.query.filter_by(
        risk_level="High"
    ).count()

    recovery_requests = PasswordRecoveryRequest.query.filter_by(
        status="Pending"
    ).all()

    return render_template(
        "hr_dashboard.html",
        employees=employees,
        tasks=tasks,
        total_employees=total_employees,
        total_tasks=total_tasks,
        total_updates=total_updates,
        high_risk=high_risk,
        recovery_requests=recovery_requests
    )


@app.route("/hr/reset_password/<int:request_id>", methods=["GET", "POST"])
def reset_employee_password(request_id):

    if not session.get("hr"):
        return redirect("/")

    recovery_request = db.session.get(
        PasswordRecoveryRequest,
        request_id
    )

    if not recovery_request or recovery_request.status != "Pending":
        flash("This recovery request is no longer pending.")
        return redirect(url_for("hr_dashboard"))

    employee = db.session.get(Employee, recovery_request.employee_id)
    if not employee:
        flash("Employee record not found.")
        return redirect(url_for("hr_dashboard"))

    if request.method == "POST":
        new_password = request.form.get("new_password", "").strip()

        if not new_password:
            flash("Enter a new password before approving the request.")
            return render_template(
                "reset_password.html",
                employee=employee,
                request_id=request_id
            )

        employee.password = new_password
        recovery_request.status = "Completed"
        db.session.commit()

        flash(f"Password reset for {employee.name}. Share it with the employee securely.")
        return redirect(url_for("hr_dashboard"))

    return render_template(
        "reset_password.html",
        employee=employee,
        request_id=request_id
    )


# ==================================================
# ADD EMPLOYEE
# ==================================================

@app.route("/add_employee", methods=["GET", "POST"])
def add_employee():

    if not session.get("hr"):
        return redirect("/")

    if request.method == "POST":

        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")
        department = request.form.get("department")
        designation = request.form.get("designation")

        # Check whether email already exists

        existing_employee = Employee.query.filter_by(
            email=email
        ).first()

        if existing_employee:

            return render_template(
                "add_employee.html",
                error="Employee with this email already exists"
            )

        employee = Employee(
            name=name,
            email=email,
            password=password,
            department=department,
            designation=designation
        )

        db.session.add(employee)
        db.session.commit()

        return redirect("/hr")

    return render_template("add_employee.html")


# ==================================================
# ASSIGN TASK PAGE
# ==================================================

@app.route("/assign_task", methods=["GET", "POST"])
def assign_task():

    if not session.get("hr"):
        return redirect("/")

    employees = Employee.query.all()

    if request.method == "POST":

        employee_id = request.form.get("employee_id")
        task_name = request.form.get("task_name")
        deadline = request.form.get("deadline")

        task = Task(
            employee_id=int(employee_id),
            task_name=task_name,
            deadline=deadline,
            status="Pending"
        )

        db.session.add(task)
        db.session.commit()

        return redirect("/hr")

    return render_template(
        "assign_task.html",
        employees=employees
    )


# ==================================================
# EMPLOYEE DASHBOARD
# ==================================================

@app.route("/employee")
def employee_dashboard():

    if "employee" not in session:
        return redirect(url_for("login"))

    employee = session["employee"]

    employee_id = employee["id"]

    tasks = Task.query.filter_by(
        employee_id=employee_id
    ).all()

    for task in tasks:
        task.timeline_status = get_task_timeline_status(task)

    warnings = [
        {
            "task_name": task.task_name,
            "message": task.timeline_status["message"]
        }
        for task in tasks
        if task.timeline_status["warning"]
    ]

    updates = WorkUpdate.query.filter_by(
        employee_id=employee_id
    ).all()
    improvement_score = calculate_improvement_score(
        sorted(updates, key=lambda update: update.id, reverse=True)
    )

    return render_template(
        "employee_dashboard.html",
        employee=employee,
        tasks=tasks,
        updates=updates,
        warnings=warnings,
        improvement_score=improvement_score
    )


# ==================================================
# EMPLOYEE WORK UPDATES
# ==================================================
@app.route("/work_updates", methods=["GET", "POST"])
def work_updates():

    if "employee" not in session:
        return redirect(url_for("login"))

    employee = session["employee"]

    if request.method == "POST":

        # Get values from the form FIRST
        task_name = request.form.get("task_name")
        hours_worked = request.form.get("hours_worked")
        completion = request.form.get("completion")
        attendance = request.form.get("attendance")
        remarks = request.form.get("remarks")

        # Check values
        if not task_name or not hours_worked or not completion or not attendance:
            flash("Please fill all required fields.")
            return redirect(url_for("work_updates"))

        # Convert numbers
        try:
            hours_worked = int(hours_worked)
            completion = int(completion)
        except ValueError:
            flash("Please enter valid numbers.")
            return redirect(url_for("work_updates"))

        # Calculate performance
        attendance_score = 100 if attendance == "Present" else 0

        performance_score = (
            completion * 0.7 +
            attendance_score * 0.3
        )

        # Calculate risk
        if performance_score >= 80:
            risk_level = "Low"
        elif performance_score >= 60:
            risk_level = "Medium"
        else:
            risk_level = "High"

        # Save to database
        new_update = WorkUpdate(
            employee_id=employee["id"],
            task_name=task_name,
            hours_worked=hours_worked,
            completion=completion,
            attendance=attendance,
            remarks=remarks,
            performance_score=performance_score,
            risk_level=risk_level
        )

        db.session.add(new_update)
        db.session.commit()

        flash("Today's work updated successfully!")

        return redirect(url_for("employee_dashboard"))

    # GET request only displays the page
    return render_template(
        "work_updates.html",
        employee=employee
    )


# ==================================================
# LEADERBOARD
# ==================================================

@app.route("/leaderboard")
def leaderboard():

    if not session.get("hr"):
        return redirect("/")

    employees = Employee.query.all()

    leaderboard_data = []

    for employee in employees:

        updates = WorkUpdate.query.filter_by(
            employee_id=employee.id
        ).all()

        scores = [
            update.performance_score
            for update in updates
            if update.performance_score is not None
        ]

        if scores:
            average_performance = sum(scores) / len(scores)
        else:
            average_performance = 0

        leaderboard_data.append({
            "name": employee.name,
            "email": employee.email,
            "department": employee.department,
            "designation": employee.designation,
            "performance": round(average_performance, 2)
        })

    # Highest performance first

    leaderboard_data.sort(
        key=lambda x: x["performance"],
        reverse=True
    )

    return render_template(
        "leaderboard.html",
        employees=leaderboard_data
    )


# ==================================================
# SEARCH EMPLOYEE
# ==================================================

@app.route("/search", methods=["GET", "POST"])
def search():

    if not session.get("hr"):
        return redirect("/")

    employees = []

    if request.method == "POST":

        search_text = request.form.get(
            "search",
            ""
        ).strip()

        employees = Employee.query.filter(
            Employee.name.ilike(
                f"%{search_text}%"
            )
        ).all()

    return render_template(
        "search.html",
        employees=employees
    )

@app.route("/update_work", methods=["GET", "POST"])
def update_work():

    # Check employee login
    if "employee" not in session:
        return redirect(url_for("login"))

    employee = session["employee"]

    if request.method == "POST":

        task_name = request.form.get("task_name")
        hours_worked = request.form.get("hours_worked")
        completion = request.form.get("completion")
        attendance = request.form.get("attendance")
        remarks = request.form.get("remarks")

        # Convert values
        try:
            hours_worked = int(hours_worked)
            completion = int(completion)
        except (ValueError, TypeError):
            flash("Please enter valid numbers.")
            return redirect(url_for("update_work"))

        # Attendance value
        attendance_value = 1 if attendance == "Present" else 0

        # Default prediction/risk
        performance_score = completion
        risk_level = "Low"

        # If your ML model is available
        if model is not None:
            try:
                prediction = model.predict(
                    np.array([[hours_worked, completion, attendance_value]])
                )[0]

                if prediction == 1:
                    risk_level = "High"
                else:
                    risk_level = "Low"

            except Exception as e:
                print("Prediction error:", e)

        # Save work update
        new_update = WorkUpdate(
            employee_id=employee["id"],
            task_name=task_name,
            hours_worked=hours_worked,
            completion=completion,
            attendance=attendance,
            remarks=remarks,
            performance_score=performance_score,
            risk_level=risk_level
        )

        db.session.add(new_update)
        db.session.commit()

        flash("Today's work updated successfully!")

        return redirect(url_for("employee_dashboard"))

    return render_template(
        "work_updates.html",
        employee=employee
    )

# ==================================================
# LOGOUT
# ==================================================

@app.route("/logout")
def logout():

    session.clear()

    return redirect("/")

@app.route("/employee_history")
def employee_history():

    if "employee" not in session:
        return redirect(url_for("login"))

    employee = session["employee"]

    employee_id = employee["id"]

    updates = WorkUpdate.query.filter_by(
        employee_id=employee_id
    ).order_by(
        WorkUpdate.id.desc()
    ).all()

    weekly_scores = {}
    for update in updates:
        if update.created_at is None or update.performance_score is None:
            continue

        update_date = update.created_at.date()
        week_start = update_date - timedelta(days=update_date.weekday())
        weekly_scores.setdefault(week_start, []).append(update.performance_score)

    performance_trend = [
        {
            "label": f"{week_start.strftime('%b')} {week_start.day}",
            "score": round(sum(scores) / len(scores), 1),
            "week_start": week_start.strftime("%Y-%m-%d")
        }
        for week_start, scores in sorted(weekly_scores.items())
    ]
    improvement_recommendations = build_improvement_recommendations(updates)
    improvement_score = calculate_improvement_score(updates)

    return render_template(
        "employee_history.html",
        employee=employee,
        updates=updates,
        performance_trend=performance_trend,
        improvement_recommendations=improvement_recommendations,
        improvement_score=improvement_score
    )


# ==================================================
# RUN APPLICATION
# ==================================================

if __name__ == "__main__":
    app.run(debug=True)