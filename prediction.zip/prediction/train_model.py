import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import joblib

# Sample training data
data = {
    "hours_worked": [8, 7, 6, 5, 9, 4, 8, 7, 6, 5],
    "completion": [95, 90, 80, 70, 98, 60, 85, 75, 65, 55],
    "attendance": [1, 1, 1, 0, 1, 0, 1, 1, 0, 0],
    "performance": [95, 90, 82, 70, 98, 60, 88, 78, 68, 55]
}

df = pd.DataFrame(data)

X = df[["hours_worked", "completion", "attendance"]]
y = df["performance"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(random_state=42)
model.fit(X_train, y_train)

accuracy = model.score(X_test, y_test)
print("Model Accuracy:", accuracy)

joblib.dump(model, "performance_model.pkl")
print("ML model saved successfully!")