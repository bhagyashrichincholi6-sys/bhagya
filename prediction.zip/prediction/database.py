from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()


class Employee(db.Model):
    __tablename__ = "employees"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    designation = db.Column(db.String(100), nullable=False)
    recovery_requests = db.relationship("PasswordRecoveryRequest", backref="employee")


class PasswordRecoveryRequest(db.Model):
    __tablename__ = "password_recovery_requests"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(
        db.Integer,
        db.ForeignKey("employees.id"),
        nullable=False
    )
    status = db.Column(db.String(20), default="Pending", nullable=False)


class Task(db.Model):
    __tablename__ = "tasks"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(
        db.Integer,
        db.ForeignKey("employees.id"),
        nullable=False
    )
    task_name = db.Column(db.String(200), nullable=False)
    deadline = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(50), default="Pending")


class WorkUpdate(db.Model):
    __tablename__ = "work_updates"

    id = db.Column(db.Integer, primary_key=True)

    employee_id = db.Column(
        db.Integer,
        db.ForeignKey("employees.id"),
        nullable=False
    )

    task_name = db.Column(db.String(200))
    hours_worked = db.Column(db.Integer)
    completion = db.Column(db.Integer)
    attendance = db.Column(db.String(20))
    remarks = db.Column(db.String(300))
    performance_score = db.Column(db.Float)
    risk_level = db.Column(db.String(30))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)